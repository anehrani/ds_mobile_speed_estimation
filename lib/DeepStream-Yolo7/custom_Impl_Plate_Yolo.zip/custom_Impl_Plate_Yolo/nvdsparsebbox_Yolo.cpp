/*
 *
 */

#include <algorithm>
#include <cmath>
#include <iostream>
#include "nvdsparsebbox_Yolo.h"

//#include "plate_results.h"
// library for the logging stuff
#include "plateInfo.h"


// modified for number plate info
static bool NvDsInferParseCustomYoloPlate(
        std::vector<NvDsInferLayerInfo> const& outputLayersInfo, NvDsInferNetworkInfo const& networkInfo,
        NvDsInferParseDetectionParams const& detectionParams, std::vector<NvDsInferInstanceMaskInfo>& objectList,
        const uint &numClasses)
{
    if (outputLayersInfo.empty())
    {
        std::cerr << "ERROR: Could not find output layer in bbox parsing" << std::endl;
        return false;
    }

    if (numClasses != detectionParams.numClassesConfigured)
    {
        std::cerr << "WARNING: Num classes mismatch. Configured: " << detectionParams.numClassesConfigured
                  << ", detected by network: " << numClasses << std::endl;
    }


//    std::cout<< "layer 0: "<<  outputLayersInfo[0].layerName << " numDim" <<  outputLayersInfo[0].inferDims.numDims << std::endl;
//    std::cout << outputLayersInfo[1].layerName << " num El" << outputLayersInfo[1].inferDims.numElements << std::endl;
//    std::cout << outputLayersInfo[2].layerName << " num El" << outputLayersInfo[2].inferDims.numElements << std::endl;


    decode_v1( outputLayersInfo, objectList );

    // non-maximum suppression
    std::sort(objectList.begin(), objectList.end(), cmp);
    nms(objectList, .5); // set nms threshold = 0.5

    return true;
}


extern "C" bool NvDsInferParesYoloPlate(
        std::vector<NvDsInferLayerInfo> const& outputLayersInfo, NvDsInferNetworkInfo const& networkInfo,
        NvDsInferParseDetectionParams const& detectionParams, std::vector<NvDsInferInstanceMaskInfo>& objectList)
{
    int num_classes = 1; // this part is hard coded



    NvDsInferParseCustomYoloPlate (
            outputLayersInfo, networkInfo, detectionParams, objectList, num_classes);



    std::cout<< " num detections: " << objectList.size() << std::endl;
    plateInfo::frame_meta tmp_frame_meta;


    for (int i=0; i< objectList.size(); i++) {

        tmp_frame_meta.top = objectList.at(i).top;
        tmp_frame_meta.left = objectList.at(i).left;
        tmp_frame_meta.width = objectList.at(i).width;
        tmp_frame_meta.height = objectList.at(i).height;
        plateInfo::objectBuffer::getInstance()->putList( tmp_frame_meta );
    }

    std::cout<< "-----------------------  \n";


    return true;
}


static void decode_v1(std::vector<NvDsInferLayerInfo> out_data, std::vector<NvDsInferInstanceMaskInfo>& preMpoints, float threshold) {
    int channels = NUM_KEYPOINTS * 3 + 6;
    int spacial_size;// = fea_w*fea_h;
    // decoding outputs at the same time
    for (int oi=0; oi< NUM_OUTPUTS; oi++){
        spacial_size = OUTPUT_DIMS[3*oi + 1] * OUTPUT_DIMS[3*oi + 2];
        float* layer_out = (float*) out_data[oi].buffer;
        // this is for 3 anchored model
        for(int c = 0; c < 3; c++)
        {
            float anchor_w = float(ANCHORS[6*oi + c * 2 + 0]);
            float anchor_h = float(ANCHORS[6*oi + c * 2 + 1]);
            float *ptr_x = layer_out + spacial_size * (c * channels + 0);
            float *ptr_y = layer_out + spacial_size * (c * channels + 1);
            float *ptr_w = layer_out + spacial_size * (c * channels + 2);
            float *ptr_h = layer_out + spacial_size * (c * channels + 3);
            float *ptr_s = layer_out + spacial_size * (c * channels + 4);
            float *ptr_c = layer_out + spacial_size * (c * channels + 5);
            // iterating over features
            for(int i = 0; i < OUTPUT_DIMS[3*oi + 2]; i++) {
                for (int j = 0; j < OUTPUT_DIMS[3*oi + 1]; j++) {
                    int index = i * OUTPUT_DIMS[3*oi + 1] + j;
                    float confidence = sigmoid(ptr_s[index]) * sigmoid(ptr_c[index]);
                    if(confidence > threshold)
                    {
                        NvDsInferInstanceMaskInfo temp_mask;
                        float dx = sigmoid(ptr_x[index]);
                        float dy = sigmoid(ptr_y[index]);
                        float dw = sigmoid(ptr_w[index]);
                        float dh = sigmoid(ptr_h[index]);
                        float pb_cx = (dx * 2.f - 0.5f + j) * STRIDE[oi];
                        float pb_cy = (dy * 2.f - 0.5f + i) * STRIDE[oi];
                        float pb_w = pow(dw * 2.f, 2) * anchor_w;
                        float pb_h = pow(dh * 2.f, 2) * anchor_h;
                        temp_mask.detectionConfidence = confidence;
                        temp_mask.top = pb_cx - pb_w * 0.5f;
                        temp_mask.left = pb_cy - pb_h * 0.5f;
                        temp_mask.width = pb_w;
                        temp_mask.height = pb_h;
                        temp_mask.mask_size = sizeof(float) * 3 * NUM_KEYPOINTS;
                        temp_mask.mask_height = 1;
                        temp_mask.mask_width = 3*NUM_KEYPOINTS;
                        temp_mask.mask = new float[3*NUM_KEYPOINTS];
                        for(int l = 0; l < NUM_KEYPOINTS; l ++)
                        {
                            temp_mask.mask[0] = (layer_out[(spacial_size * (c * channels + l * 3 + 6)) + index] * 2 - 0.5 + j) * STRIDE[oi];
                            temp_mask.mask[1] = (layer_out[(spacial_size * (c * channels + l * 3 + 7)) + index] * 2 - 0.5 + i) * STRIDE[oi];
                            temp_mask.mask[2] = sigmoid(layer_out[spacial_size * (c * channels + l * 3 + 8) + index]); // this is confidence of the poin
                        }
                        preMpoints.push_back(temp_mask);
                    } // end of if

                } // end of for j
            } // end of for i

        } // end of for c

    } // end of for oi number of network outputs
}

//
void nms(std::vector<NvDsInferInstanceMaskInfo> &input_boxes, float NMS_THRESH)
{
    std::vector<float>vArea(input_boxes.size());
    for (int i = 0; i < int(input_boxes.size()); ++i)
    {
        vArea[i] = (input_boxes.at(i).width + 1)
                   * (input_boxes.at(i).height + 1);
    }
    for (int i = 0; i < int(input_boxes.size()); ++i)
    {
        for (int j = i + 1; j < int(input_boxes.size());)
        {
            float xx1 = std::max(input_boxes[i].left, input_boxes[j].left);
            float yy1 = std::max(input_boxes[i].top, input_boxes[j].top);
            float xx2 = std::min(input_boxes[i].left + input_boxes[i].width, input_boxes[j].left + input_boxes[j].width);
            float yy2 = std::min(input_boxes[i].top + input_boxes[i].height, input_boxes[j].top + input_boxes[j].height);
            float w = std::max(float(0), xx2 - xx1 + 1);
            float h = std::max(float(0), yy2 - yy1 + 1);
            float inter = w * h;
            float ovr = inter / (vArea[i] + vArea[j] - inter);
            if (ovr >= NMS_THRESH)
            {
                input_boxes.erase(input_boxes.begin() + j);
                vArea.erase(vArea.begin() + j);
            }
            else
            {
                j++;
            }
        }
    }
}




CHECK_CUSTOM_INSTANCE_MASK_PARSE_FUNC_PROTOTYPE(NvDsInferParesYoloPlate)




